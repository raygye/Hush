# Hush
Hush is a program that allows the user to encrypt their messages using OTP encryption. 

Simply encode your message, send the unreadable script to a peer, and have them decode it on their end. Such a technology was developed
by Claude Shannon and was notably used in WWII.

Choose any key that you wish, but do not reuse keys. Key reuse is a major security flaw that can lead to message leaks.

A jar is available to run the program.

Note: On first use of the application, please wait as it compiles the .exe file. 